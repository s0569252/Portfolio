const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const verkehrRoutes = require('./routes/verkehr');
const flugRoutes = require('./routes/flug');
const schiffRoutes = require('./routes/schiff');
const stromRoutes = require('./routes/strom');
const waermeRoutes = require('./routes/waerme');
const testRoutes = require('./routes/test');

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
.then(() => {
    console.log('Connected to MongoDB');
}).catch((error) => {
    console.error('Connection error', error);
});

app.use('/verkehr', verkehrRoutes);
app.use('/flug', flugRoutes);
app.use('/schiff', schiffRoutes);
app.use('/strom', stromRoutes);
app.use('/waerme', waermeRoutes);
app.use('/api', testRoutes);

const PORT = process.env.PORT || 5062;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
