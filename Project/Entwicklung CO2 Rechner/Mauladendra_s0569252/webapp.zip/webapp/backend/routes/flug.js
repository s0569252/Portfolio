const express = require('express');
const router = express.Router();
const Factor = require('../models/factor');
const Result = require('../models/result');

// Route for calculating CO2 emissions from flights
router.post('/calculate', async (req, res) => {
    const { distance } = req.body;

    // Validate input
    if (!distance || typeof distance !== 'number' || distance <= 0) {
        return res.status(400).json({ message: 'Distance must be a positive number' });
    }

    try {
        // Find the factor for flights
        const factor = await Factor.findOne({ category: 'Flug' });
        if (!factor) {
            return res.status(404).json({ message: 'Factor not found for flights' });
        }

        // Calculate emission
        const emission = factor.value * distance;

        // Save result to database
        const result = new Result({ category: 'Flug', emission });
        await result.save();

        // Return calculated emission
        res.json({ emission });
    } catch (error) {
        console.error('Error calculating emission:', error);
        res.status(500).json({ message: 'Server Error', error: error.message });
    }
});

module.exports = router;
