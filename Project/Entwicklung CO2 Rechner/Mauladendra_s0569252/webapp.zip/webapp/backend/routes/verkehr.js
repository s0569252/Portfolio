const express = require('express');
const router = express.Router();
const Factor = require('../models/factor');
const Result = require('../models/result');

// Route for calculating CO2 emissions
router.post('/calculate', async (req, res) => {
    const { fuelType, distance } = req.body;

    // Validate input
    if (!fuelType || typeof fuelType !== 'string' || fuelType.trim() === '') {
        return res.status(400).json({ message: 'Fuel type is required and cannot be empty' });
    }
    if (!distance || typeof distance !== 'number' || distance <= 0) {
        return res.status(400).json({ message: 'Distance must be a positive number' });
    }

    try {
        // Find the factor based on category and fuelType
        const factor = await Factor.findOne({ category: 'Verkehr', fuelType });
        if (!factor) {
            return res.status(404).json({ message: 'Factor not found for the given fuel type' });
        }

        // Calculate emission
        const emission = factor.value * distance;

        // Save result to database
        const result = new Result({ category: 'Verkehr', fuelType, emission });
        await result.save();

        // Return calculated emission
        res.json({ emission });
    } catch (error) {
        console.error('Error calculating emission:', error);
        res.status(500).json({ message: 'Server Error', error: error.message });
    }
});

module.exports = router;
