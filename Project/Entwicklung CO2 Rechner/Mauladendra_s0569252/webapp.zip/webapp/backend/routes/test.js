const express = require('express');
const router = express.Router();
const Factor = require('../models/factor');

router.get('/test-db', async (req, res) => {
    try {
        const factors = await Factor.find(); // Fetch all documents from the 'factor' collection
        res.json(factors); // Return the results as a JSON response
    } catch (error) {
        console.error('Database connection error:', error);
        res.status(500).json({ message: 'Database connection error', error: error.message });
    }
});

module.exports = router;
