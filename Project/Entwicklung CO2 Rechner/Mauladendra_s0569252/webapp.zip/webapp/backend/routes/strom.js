const express = require('express');
const router = express.Router();
const Factor = require('../models/factor');
const Result = require('../models/result');

// Route for calculating CO2 emissions from electricity
router.post('/calculate', async (req, res) => {
    const { consumption } = req.body;

    // Validate input
    if (!consumption || typeof consumption !== 'number' || consumption <= 0) {
        return res.status(400).json({ message: 'Consumption must be a positive number' });
    }

    try {
        // Find the factor for electricity
        const factor = await Factor.findOne({ category: 'Strom' });
        if (!factor) {
            return res.status(404).json({ message: 'Factor not found for electricity' });
        }

        // Calculate emission
        const emission = factor.value * consumption;

        // Save result to database
        const result = new Result({ category: 'Strom', emission });
        await result.save();

        // Return calculated emission
        res.json({ emission });
    } catch (error) {
        console.error('Error calculating emission:', error);
        res.status(500).json({ message: 'Server Error', error: error.message });
    }
});

module.exports = router;
