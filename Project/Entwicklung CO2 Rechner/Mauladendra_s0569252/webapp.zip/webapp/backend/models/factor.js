const mongoose = require('mongoose');

const factorSchema = new mongoose.Schema({
    category: { type: String, required: true },
    fuelType: { type: String },
    value: { type: Number, required: true },
});

module.exports = mongoose.model('Factor', factorSchema);
