const mongoose = require('mongoose');

const resultSchema = new mongoose.Schema({
    category: { type: String, required: true },
    fuelType: { type: String },
    emission: { type: Number, required: true },
    date: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Result', resultSchema);
