import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { IonPage, IonHeader, IonContent, IonFooter } from '@ionic/react';

import Header from './components/Header';
import Footer from './components/Footer';
import Navigation from './components/Navigation';

import Home from './pages/Home';
import Verkehr from './pages/Verkehr';
import Flug from './pages/Flug';
import Schiff from './pages/Schiff';
import Strom from './pages/Strom';
import Waerme from './pages/Waerme';
import Recommendations from './pages/Recommendations';

const App = () => (
  <Router>
    <IonPage>
      <IonHeader>
        <Header />
      </IonHeader>
      <IonContent>
        <Navigation />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/verkehr" element={<Verkehr />} />
          <Route path="/flug" element={<Flug />} />
          <Route path="/schiff" element={<Schiff />} />
          <Route path="/strom" element={<Strom />} />
          <Route path="/waerme" element={<Waerme />} />
          <Route path="/recommendations" element={<Recommendations />} />
        </Routes>
      </IonContent>
      <IonFooter>
        <Footer />
      </IonFooter>
    </IonPage>
  </Router>
);

export default App;
