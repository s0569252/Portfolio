// src/services/apiService.js
import axios from 'axios';

const apiService = {
  calculateEmissions: async (category, data) => {
    const response = await axios.post(`http://localhost:5062/${category}/calculate`, data);
    return response;
  },
};

export default apiService;
