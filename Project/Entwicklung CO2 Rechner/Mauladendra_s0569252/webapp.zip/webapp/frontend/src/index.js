import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import '@ionic/react/css/core.css'; // Core CSS required for Ionic components to work properly
import '@ionic/react/css/normalize.css'; // Normalize.css for consistent styling
import '@ionic/react/css/structure.css'; // Basic CSS for Ionic components
import '@ionic/react/css/typography.css'; // Typography CSS for consistent text styling

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
