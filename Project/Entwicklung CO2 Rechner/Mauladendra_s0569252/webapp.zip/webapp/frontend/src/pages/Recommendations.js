// src/pages/Recommendations.js
import React from 'react';
import { IonContent, IonPage, IonList, IonItem, IonLabel } from '@ionic/react';
import '../styles/app.css'; // Make sure to import the CSS

const Recommendations = () => {
  return (
    <IonPage>
      <IonContent>
      <div className="form-box"> {/* Add this div */}
        <IonList>
          <IonItem>
            <IonLabel>
              <h2>Recommendation 1</h2>
              <p>Reduce car travel by using public transportation or biking.</p>
            </IonLabel>
          </IonItem>
          <IonItem>
            <IonLabel>
              <h2>Recommendation 2</h2>
              <p>Switch to renewable energy sources for your home.</p>
            </IonLabel>
          </IonItem>
          <IonItem>
            <IonLabel>
              <h2>Recommendation 3</h2>
              <p>Consider flying less and use trains for longer journeys.</p>
            </IonLabel>
          </IonItem>
          {/* Add more recommendations as needed */}
        </IonList>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Recommendations;
