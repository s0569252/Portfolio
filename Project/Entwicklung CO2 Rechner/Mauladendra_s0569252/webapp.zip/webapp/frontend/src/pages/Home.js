import React from 'react';
import { IonContent } from '@ionic/react';
import '../styles/app.css';
import tree from '../images/tree.png';

function Home() {
  return (
    <IonContent className="home-content">
      <div className="welcome-section">
        <h1>Welcome to CO2 Rechner</h1>
        <img src={tree} alt="Tree" className="welcome-image" />
      </div>

    </IonContent>
  );
}

export default Home;
