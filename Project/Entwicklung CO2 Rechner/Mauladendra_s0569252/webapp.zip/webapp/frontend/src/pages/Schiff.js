// src/pages/Flug.js
import React, { useState } from 'react';
import { IonContent, IonPage, IonButton, IonAlert, IonCard, IonCardHeader, IonCardTitle, IonCardContent } from '@ionic/react';
import DistanceInput from '../components/DistanceInput';
import apiService from '../services/apiService';
import '../styles/app.css'; // Make sure to import the CSS

const Schiff = () => {
  const [distance, setDistance] = useState(0);
  const [emission, setEmission] = useState(null);
  const [error, setError] = useState(null);

  const handleCalculate = async () => {
    try {
      const response = await apiService.calculateEmissions('schiff', { distance });
      setEmission(response.data.emission);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.message || 'An error occurred');
      setEmission(null);
    }
  };

  const handleReset = () => {
    setDistance(0);
    setEmission(null);
    setError(null);
  };

  return (
    <IonPage>
        <IonContent className="page-container">
            <IonCard className="input-card">
                <IonCardHeader>
                    <IonCardTitle className="page-title">CO2 Emissions Calculation for Schiff</IonCardTitle>
                </IonCardHeader>
                <IonCardContent>
                <div className="form-box"> {/* Add this div */}
                    <div className="section-container">
                        <h2 className="section-title">Enter Distance</h2>
                        <DistanceInput distance={distance} setDistance={setDistance} />
                    </div>
                    <div className="button-group">
                        <IonButton className="button" expand="full" onClick={handleCalculate}>Calculate</IonButton>
                        <IonButton className="button" expand="full" color="light" onClick={handleReset}>Reset</IonButton>
                    </div>
                </div>
                    {emission !== null && (
                        <div className="info-box">
                            Emission: <strong>{emission} kg CO2</strong>
                        </div>
                    )}
                    {error && (
                        <IonAlert
                            isOpen={!!error}
                            onDidDismiss={() => setError(null)}
                            message={error}
                            buttons={['OK']}
                        />
                    )}
                </IonCardContent>
            </IonCard>
        </IonContent>
    </IonPage>
);
};

export default Schiff;
