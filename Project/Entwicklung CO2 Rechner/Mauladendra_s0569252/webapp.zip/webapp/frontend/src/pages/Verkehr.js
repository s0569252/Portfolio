import React, { useState } from 'react';
import { IonContent, IonPage, IonButton, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonAlert } from '@ionic/react';
import FuelTypeSelector from '../components/FuelTypeSelector';
import DistanceInput from '../components/DistanceInput';
import apiService from '../services/apiService';
import '../styles/app.css';

const Verkehr = () => {
    const [fuelType, setFuelType] = useState('');
    const [distance, setDistance] = useState('');
    const [emission, setEmission] = useState(null);
    const [error, setError] = useState(null);

    const handleCalculate = async () => {
        try {
          const response = await apiService.calculateEmissions('verkehr', { fuelType, distance });
          setEmission(response.data.emission);
          setError(null);
        } catch (err) {
          setError(err.response?.data?.message || 'An error occurred');
          setEmission(null);
        }
    };

    const handleReset = () => {
        setFuelType('');
        setDistance('');
        setEmission(null);
        setError(null);
    };

    return (
        <IonPage>
            <IonContent className="page-container">
                <IonCard className="input-card">
                    <IonCardHeader>
                        <IonCardTitle className="page-title">CO2 Emissions Calculation for Verkehr</IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent>
                        <div className="form-box"> {/* Add this div */}
                            <div className="section-container">
                                <h2 className="section-title">Select Fuel Type</h2>
                                <FuelTypeSelector fuelType={fuelType} setFuelType={setFuelType} />
                            </div>
                            <div className="section-container">
                                <h2 className="section-title">Enter Distance</h2>
                                <DistanceInput distance={distance} setDistance={setDistance} />
                            </div>
                            <div className="button-group">
                                <IonButton className="button" expand="full" onClick={handleCalculate}>Calculate</IonButton>
                                <IonButton className="button" expand="full" color="light" onClick={handleReset}>Reset</IonButton>
                            </div>
                            {emission !== null && (
                                <div className="info-box">
                                    Emission: <strong>{emission} kg CO2</strong>
                                </div>
                            )}
                        </div> {/* Close the div */}
                        {error && (
                            <IonAlert
                                isOpen={!!error}
                                onDidDismiss={() => setError(null)}
                                message={error}
                                buttons={['OK']}
                            />
                        )}
                    </IonCardContent>
                </IonCard>
            </IonContent>
        </IonPage>
    );
};

export default Verkehr;
