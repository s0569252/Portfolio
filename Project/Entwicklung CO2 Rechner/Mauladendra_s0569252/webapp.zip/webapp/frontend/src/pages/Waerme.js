// src/pages/Waerme.js
import React, { useState } from 'react';
import { IonContent, IonPage, IonButton, IonAlert, IonCard, IonCardHeader, IonCardTitle, IonCardContent } from '@ionic/react';
import EnergyInput from '../components/EnergyInput';
import apiService from '../services/apiService';

const Waerme = () => {
  const [consumption, setConsumption] = useState(0);
  const [emission, setEmission] = useState(null);
  const [error, setError] = useState(null);

  const handleCalculate = async () => {
    try {
      const response = await apiService.calculateEmissions('waerme', { consumption });
      setEmission(response.data.emission);
      setError(null);
    } catch (err) {
      setError(err.response.data.message);
      setEmission(null);
    }
  };

  const handleReset = () => {
    setConsumption(0);
    setEmission(null);
    setError(null);
  };

  return (
<IonPage>
        <IonContent className="page-container">
            <IonCard className="input-card">
                <IonCardHeader>
                    <IonCardTitle className="page-title">CO2 Emissions Calculation for Strom</IonCardTitle>
                </IonCardHeader>
                <IonCardContent>
                <div className="form-box"> {/* Add this div */}
                    <div className="section-container">
                        <h2 className="section-title">Enter Energy</h2>
                        <EnergyInput energy={consumption} setEnergy={setConsumption} />
                    </div>
                    <div className="button-group">
                        <IonButton className="button" expand="full" onClick={handleCalculate}>Calculate</IonButton>
                        <IonButton className="button" expand="full" color="light" onClick={handleReset}>Reset</IonButton>
                    </div>
                </div>
                    {emission !== null && (
                        <div className="info-box">
                            Emission: <strong>{emission} kg CO2</strong>
                        </div>
                    )}
                    {error && (
                        <IonAlert
                            isOpen={!!error}
                            onDidDismiss={() => setError(null)}
                            message={error}
                            buttons={['OK']}
                        />
                    )}
                </IonCardContent>
            </IonCard>
        </IonContent>
    </IonPage>
  );
};

export default Waerme;
