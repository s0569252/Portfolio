// src/components/EnergyInput.js
import React from 'react';
import { IonInput, IonItem, IonLabel } from '@ionic/react';

const KwhInput = ({ energy, setEnergy }) => (
    <IonItem>
      <IonLabel>Anual energy usage (kWh/year)</IonLabel>
      <IonInput type="number" value={energy} onIonChange={e => setEnergy(parseFloat(e.detail.value))} />
    </IonItem>
  );

export default KwhInput;
