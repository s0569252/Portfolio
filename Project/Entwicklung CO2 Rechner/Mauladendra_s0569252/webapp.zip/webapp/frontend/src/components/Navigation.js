import React, { useState } from 'react';
import { IonButton, IonButtons } from '@ionic/react';
import '../styles/app.css';

function Navigation() {
  const [activeTab, setActiveTab] = useState('Home');

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="navigation-menu">
      <IonButtons className="nav-buttons">
        <IonButton 
          routerLink="/" 
          className={`nav-button ${activeTab === 'Home' ? 'active' : ''}`}
          onClick={() => handleTabClick('Home')}
        >Home</IonButton>
        <IonButton 
          routerLink="/verkehr" 
          className={`nav-button ${activeTab === 'Verkehr' ? 'active' : ''}`}
          onClick={() => handleTabClick('Verkehr')}
        >Verkehr</IonButton>
        <IonButton 
          routerLink="/flug" 
          className={`nav-button ${activeTab === 'Flug' ? 'active' : ''}`}
          onClick={() => handleTabClick('Flug')}
        >Flug</IonButton>
        <IonButton 
          routerLink="/schiff" 
          className={`nav-button ${activeTab === 'Schiff' ? 'active' : ''}`}
          onClick={() => handleTabClick('Schiff')}
        >Schiff</IonButton>
        <IonButton 
          routerLink="/strom" 
          className={`nav-button ${activeTab === 'Strom' ? 'active' : ''}`}
          onClick={() => handleTabClick('Strom')}
        >Strom</IonButton>
        <IonButton 
          routerLink="/waerme" 
          className={`nav-button ${activeTab === 'Wärme' ? 'active' : ''}`}
          onClick={() => handleTabClick('Waerme')}
        >Waerme</IonButton>
        <IonButton 
          routerLink="/recommendations" 
          className={`nav-button ${activeTab === 'Recommendations' ? 'active' : ''}`}
          onClick={() => handleTabClick('Recommendations')}
        >Recommendations</IonButton>
      </IonButtons>
      <div className="blue-line"></div>
    </div>
  );
}

export default Navigation;