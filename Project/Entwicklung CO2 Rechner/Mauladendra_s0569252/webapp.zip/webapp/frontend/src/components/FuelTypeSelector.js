import React from 'react';

const FuelTypeSelector = ({ fuelType, setFuelType }) => {
  return (
    <div className="fuel-type-selector">
      <label htmlFor="fuel-type-select" className="fuel-type-label">Fuel Type</label>
      <select
        id="fuel-type-select"
        value={fuelType}
        onChange={(e) => setFuelType(e.target.value)}
        className="fuel-type-select"
      >
        <option value="">Select Fuel Type</option>
        <option value="Benzin">Benzin</option>
        <option value="Diesel">Diesel</option>
        <option value="Electric">Electric</option>
        {/* Add more options as needed */}
      </select>
    </div>
  );
};

export default FuelTypeSelector;
