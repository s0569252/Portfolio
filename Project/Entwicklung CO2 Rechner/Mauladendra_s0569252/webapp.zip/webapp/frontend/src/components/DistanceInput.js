// src/components/DistanceInput.js
import React from 'react';
import { IonInput, IonItem, IonLabel } from '@ionic/react';

const DistanceInput = ({ distance, setDistance }) => (
  <IonItem>
    <IonLabel>Distance (km)</IonLabel>
    <IonInput type="number" value={distance} onIonChange={e => setDistance(parseFloat(e.detail.value))} />
  </IonItem>
);

export default DistanceInput;
