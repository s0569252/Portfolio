// src/components/KwhInput.js
import React from 'react';
import { IonInput, IonItem, IonLabel } from '@ionic/react';

const KwhInput = ({ kWh, setKWh }) => (
    <IonItem>
      <IonLabel>Anual electricity usage (kWh/year)</IonLabel>
      <IonInput type="number" value={kWh} onIonChange={e => setKWh(parseFloat(e.detail.value))} />
    </IonItem>
  );

export default KwhInput;
