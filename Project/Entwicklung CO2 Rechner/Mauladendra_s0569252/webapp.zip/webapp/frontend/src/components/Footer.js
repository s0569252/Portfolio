import React from 'react';
import { IonFooter } from '@ionic/react';
import '../styles/app.css';

function Footer() {
  return (
    <IonFooter className="footer">
      <div className="footer-content">
        <p>© 2024 CO2 Rechner. All rights reserved.</p>
      </div>
    </IonFooter>
  );
}

export default Footer;
