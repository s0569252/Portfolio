import React from 'react';
import { IonToolbar, IonTitle, IonHeader } from '@ionic/react';
import { Link } from 'react-router-dom';
import '../styles/app.css';
import logo from '../images/CarbonTrack.png'; // Add your logo image here

function Header() {
  return (
    <IonHeader className="header">
      <IonToolbar className="header-toolbar">
        <div className="header-content">
          <img src={logo} alt="Logo" className="header-logo" />
          <IonTitle className="header-title">
            <Link to="/">CO2 Rechner</Link>
          </IonTitle>
        </div>
      </IonToolbar>
    </IonHeader>
  );
}

export default Header;
